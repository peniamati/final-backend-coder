const express = require("express");
const { Router } = express;
const passport = require("passport");
const route = new Router();
const {
  register,
  login,
  loginGithub,
  loginGithubCallback,
  logout,
  getCurrentUser,
  renderProfilePage,
} = require("../controllers/authControllers");
const UserDTO = require("../dao/dto/user.Dto");

route.post("/register", register);
route.post("/login", login);
route.get("/login_github", loginGithub);
route.get(
  "/login_github/callback",
  passport.authenticate("login_github", {
    session: false,
  }),
  loginGithubCallback
);
route.post("/logout", logout);
// Ruta para mostrar el perfil actual
route.get("/current", (req, res) => {
  // Obtener datos del usuario y renderizar la página de perfil
  const user = new UserDTO(
    req.session.user._id,
    req.session.user.email,
    req.session.user.name,
    req.session.user.lastname,
    req.session.user.age,
    req.session.user.password,
    req.session.user.cart,
    req.session.user.role,
    req.session.user.documents
  );
  const data = user.getData(); // Aquí se debería obtener el usuario de la sesión o de la base de datos
  res.render("profile", { data });
});

// Ruta para procesar la actualización del perfil
route.post("/update-profile", (req, res) => {
  // Obtener los datos del formulario de la solicitud POST
  const { name, lastname } = req.body;

  // Actualizar los datos del usuario
  user.updateData({ name, lastname });

  // Redireccionar a la página de perfil actualizada
  res.redirect("/current");
});

module.exports = route;
