class UserDTO {
  constructor(email, name) {
    this.email = email;
    this.name = name;
  }
}

module.exports = UserDTO;
